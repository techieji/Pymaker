"Pymaker, the better `make`"
__version__ = '0.0.1'

from .pymaker import *
