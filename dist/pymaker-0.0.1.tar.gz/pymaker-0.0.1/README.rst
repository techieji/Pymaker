=======
Pymaker
=======

Pymaker is the better alternative to make. Let me tell you why.

I don't know if you're like me, but I am no good at shell scripting. Make
just exasperated those issues for me. On top of that, make made it harder to
do stuff. For example, taking command line args (I never figured out how to do
that with make). So, I made Pymaker to take advantage of Python's extensibility.
